<?php
require_once __DIR__ . '/../config/cors.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../helpers/response.php';

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

$conn = getDbConnection();
$action = $_GET['action'] ?? '';
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

if ($action === 'login' && $method === 'POST') {
    $data = getJsonInput();
    $username = trim((string)($data['username'] ?? ''));
    $password = (string)($data['password'] ?? '');
    $role = strtolower(trim((string)($data['role'] ?? '')));

    if ($username === '' || $password === '' || !in_array($role, ['admin', 'user'], true)) {
        sendResponse(false, 'Username, password and valid role are required', null, 400);
    }

    $stmt = $conn->prepare('SELECT id, username, full_name, password_hash, role, status FROM users WHERE username = ? AND role = ? LIMIT 1');
    $stmt->bind_param('ss', $username, $role);
    $stmt->execute();
    $user = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$user || $user['status'] !== 'Active' || !password_verify($password, $user['password_hash'])) {
        sendResponse(false, 'Invalid username, password or account role', null, 401);
    }

    session_regenerate_id(true);
    $_SESSION['user'] = [
        'id' => (int)$user['id'],
        'username' => $user['username'],
        'full_name' => $user['full_name'],
        'role' => $user['role']
    ];

    sendResponse(true, 'Login successful', $_SESSION['user']);
}

if ($action === 'me' && $method === 'GET') {
    if (!empty($_SESSION['user'])) {
        sendResponse(true, 'Authenticated', $_SESSION['user']);
    }
    sendResponse(false, 'Not authenticated', null, 401);
}

if ($action === 'logout' && $method === 'POST') {
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
    }
    session_destroy();
    sendResponse(true, 'Logged out successfully');
}

sendResponse(false, 'Invalid authentication request', null, 400);
