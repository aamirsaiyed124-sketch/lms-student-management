import React from 'react';

export default function StatCard({ title, value, icon, color = 'primary', subtitle }) {
  const bgMap = {
    primary: 'bg-primary-subtle text-primary',
    success: 'bg-success-subtle text-success',
    warning: 'bg-warning-subtle text-warning',
    info: 'bg-info-subtle text-info',
    danger: 'bg-danger-subtle text-danger',
  };

  return (
    <div className="card stat-card h-100 border-0 p-3">
      <div className="d-flex justify-content-between align-items-start">
        <div>
          <span className="text-muted fw-semibold small text-uppercase" style={{ letterSpacing: '0.04em' }}>
            {title}
          </span>
          <h2 className="fw-bold text-dark mt-1 mb-0">{value}</h2>
          {subtitle && (
            <p className="text-muted small mb-0 mt-1 d-flex align-items-center gap-1">
              <i className="bi bi-arrow-up-right-circle text-success"></i>
              {subtitle}
            </p>
          )}
        </div>
        <div className={`stat-icon-wrapper ${bgMap[color] || bgMap.primary}`}>
          <i className={`bi ${icon}`}></i>
        </div>
      </div>
    </div>
  );
}
