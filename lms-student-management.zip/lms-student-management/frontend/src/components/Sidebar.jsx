import React from 'react';

export default function Sidebar({ activeTab, setActiveTab, role = 'admin' }) {
  const allItems = [
    { id: 'dashboard', label: 'Dashboard', icon: 'bi-grid-1x2-fill', roles: ['admin', 'user'] },
    { id: 'students', label: 'Students Directory', icon: 'bi-people-fill', roles: ['admin'] },
    { id: 'courses', label: 'Courses & Catalog', icon: 'bi-journal-bookmark-fill', roles: ['admin', 'user'] },
    { id: 'enrollments', label: 'Enrollments & Grades', icon: 'bi-card-checklist', roles: ['admin'] },
    { id: 'attendance', label: 'Attendance Tracker', icon: 'bi-calendar-check-fill', roles: ['admin'] },
    { id: 'notices', label: 'Notice Board', icon: 'bi-megaphone-fill', roles: ['admin', 'user'] },
  ];
  const menuItems = allItems.filter(item => item.roles.includes(role));

  return (
    <aside className="sidebar-wrapper d-flex flex-column justify-content-between p-3">
      <div>
        <div className="d-flex align-items-center gap-2 px-2 py-3 mb-3 border-bottom">
          <div className="bg-primary text-white p-2 rounded-3 shadow-sm d-flex align-items-center justify-content-center"><i className="bi bi-mortarboard fs-5"></i></div>
          <div><h6 className="mb-0 fw-bold text-dark">EduPulse</h6><small className="text-muted" style={{ fontSize: '0.725rem' }}>Student Management</small></div>
        </div>
        <div className="text-uppercase text-muted px-3 mb-2 fw-semibold" style={{ fontSize: '0.7rem', letterSpacing: '0.08em' }}>Main Navigation</div>
        <nav className="nav flex-column gap-1">
          {menuItems.map((item) => {
            const isActive = activeTab === item.id;
            return <button key={item.id} onClick={() => setActiveTab(item.id)} className={`nav-link-custom border-0 w-100 text-start ${isActive ? 'active' : 'bg-transparent'}`}><i className={`bi ${item.icon} fs-5`}></i><span>{item.label}</span></button>;
          })}
        </nav>
      </div>
      <div className="p-3 bg-light rounded-3 border">
        <div className="d-flex align-items-center gap-2 mb-1"><i className="bi bi-person-badge-fill text-primary"></i><span className="fw-semibold small">{role === 'admin' ? 'Administrator' : 'User Account'}</span></div>
        <p className="text-muted mb-0" style={{ fontSize: '0.75rem', lineHeight: '1.3' }}>{role === 'admin' ? 'Full management access.' : 'View-only student portal access.'}</p>
      </div>
    </aside>
  );
}
