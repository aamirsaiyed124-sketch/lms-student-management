import React from 'react';

export default function ToastAlert({ alert, onClose }) {
  if (!alert || !alert.message) return null;

  const bgClass = alert.type === 'error' ? 'bg-danger' : alert.type === 'warning' ? 'bg-warning text-dark' : 'bg-success';
  const iconClass = alert.type === 'error' ? 'bi-exclamation-octagon-fill' : alert.type === 'warning' ? 'bi-exclamation-triangle-fill' : 'bi-check-circle-fill';

  return (
    <div 
      className="position-fixed top-0 end-0 p-3" 
      style={{ zIndex: 1080, maxWidth: '400px' }}
    >
      <div 
        className={`toast show align-items-center text-white ${bgClass} border-0 shadow-lg`} 
        role="alert" 
        aria-live="assertive" 
        aria-atomic="true"
      >
        <div className="d-flex">
          <div className="toast-body d-flex align-items-center gap-2 fs-6">
            <i className={`bi ${iconClass} fs-5`}></i>
            <div>{alert.message}</div>
          </div>
          <button 
            type="button" 
            className="btn-close btn-close-white me-2 m-auto" 
            onClick={onClose} 
            aria-label="Close"
          ></button>
        </div>
      </div>
    </div>
  );
}
