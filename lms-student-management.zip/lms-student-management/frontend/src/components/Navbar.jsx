import React from 'react';

export default function Navbar({ serverStatus, user, onLogout }) {
  const initials = (user?.full_name || user?.username || 'U').split(' ').map(x => x[0]).join('').slice(0, 2).toUpperCase();
  const roleLabel = user?.role === 'admin' ? 'Administrator' : 'User';

  return (
    <header className="top-navbar d-flex justify-content-between align-items-center">
      <div className="d-flex align-items-center gap-3">
        <h5 className="mb-0 fw-bold text-dark d-flex align-items-center gap-2"><i className="bi bi-mortarboard-fill text-primary fs-4"></i><span>EduPulse LMS</span><span className="badge bg-primary-subtle text-primary border border-primary-subtle rounded-pill ms-2 fw-semibold px-2 py-1 fs-7">Minor Project Edition</span></h5>
      </div>
      <div className="d-flex align-items-center gap-3">
        <span className={`badge d-inline-flex align-items-center gap-1.5 px-2.5 py-1.5 rounded-pill ${serverStatus ? 'bg-success-subtle text-success border border-success-subtle' : 'bg-danger-subtle text-danger border border-danger-subtle'}`}><span className={`p-1 rounded-circle ${serverStatus ? 'bg-success' : 'bg-danger'}`}></span><span className="fw-medium">{serverStatus ? 'PHP/MySQLi Online' : 'Connecting to API...'}</span></span>
        <div className="d-none d-md-flex align-items-center text-muted small border-start ps-3"><i className="bi bi-calendar3 me-1 text-primary"></i><span>Academic Term 2026</span></div>
        <div className="d-flex align-items-center gap-2 border-start ps-3">
          <div className="rounded-circle bg-primary text-white d-flex align-items-center justify-content-center fw-bold shadow-sm" style={{ width: '36px', height: '36px', fontSize: '0.85rem' }}>{initials}</div>
          <div className="d-none d-lg-block text-start lh-sm"><div className="fw-semibold small">{user?.full_name || user?.username}</div><span className="text-muted" style={{ fontSize: '0.75rem' }}>{roleLabel}</span></div>
          <button className="btn btn-sm btn-outline-danger ms-1" onClick={onLogout} title="Logout"><i className="bi bi-box-arrow-right"></i></button>
        </div>
      </div>
    </header>
  );
}
