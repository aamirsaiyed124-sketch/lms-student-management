import React, { useEffect, useState } from 'react';
import axiosClient from '../api/axiosClient';

const INITIAL_FORM = {
  course_code: '',
  title: '',
  description: '',
  credits: 3,
  instructor_name: '',
  department: 'Computer Science',
  semester: 1
};

export default function Courses({ showAlert, role = 'admin' }) {
  const [courses, setCourses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [departmentFilter, setDepartmentFilter] = useState('All');

  const [showModal, setShowModal] = useState(false);
  const [editingCourse, setEditingCourse] = useState(null);
  const [formData, setFormData] = useState(INITIAL_FORM);

  const [showRosterModal, setShowRosterModal] = useState(false);
  const [selectedCourseRoster, setSelectedCourseRoster] = useState(null);
  const [rosterLoading, setRosterLoading] = useState(false);

  const [deleteTarget, setDeleteTarget] = useState(null);

  const departments = [
    'Computer Science',
    'Information Technology',
    'Data Science',
    'Electrical Engineering',
    'Mechanical Engineering',
    'Civil Engineering'
  ];

  const fetchCourses = async () => {
    try {
      setLoading(true);
      const params = {};
      if (search.trim()) params.search = search.trim();
      if (departmentFilter !== 'All') params.department = departmentFilter;

      const res = await axiosClient.get('/courses.php', { params });
      if (res.success) {
        setCourses(res.data);
      }
    } catch (err) {
      showAlert(err.message, 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const timer = setTimeout(() => {
      fetchCourses();
    }, 300);
    return () => clearTimeout(timer);
  }, [search, departmentFilter]);

  const handleOpenAdd = () => {
    setEditingCourse(null);
    setFormData(INITIAL_FORM);
    setShowModal(true);
  };

  const handleOpenEdit = (course) => {
    setEditingCourse(course);
    setFormData({
      id: course.id,
      course_code: course.course_code,
      title: course.title,
      description: course.description || '',
      credits: course.credits,
      instructor_name: course.instructor_name,
      department: course.department,
      semester: course.semester
    });
    setShowModal(true);
  };

  const handleSaveCourse = async (e) => {
    e.preventDefault();
    try {
      if (editingCourse) {
        const res = await axiosClient.put('/courses.php', formData);
        if (res.success) {
          showAlert('Course updated successfully', 'success');
        }
      } else {
        const res = await axiosClient.post('/courses.php', formData);
        if (res.success) {
          showAlert('Course created successfully', 'success');
        }
      }
      setShowModal(false);
      fetchCourses();
    } catch (err) {
      showAlert(err.message, 'error');
    }
  };

  const handleOpenRoster = async (courseId) => {
    setShowRosterModal(true);
    setRosterLoading(true);
    try {
      const res = await axiosClient.get(`/courses.php?id=${courseId}`);
      if (res.success) {
        setSelectedCourseRoster(res.data);
      }
    } catch (err) {
      showAlert(err.message, 'error');
      setShowRosterModal(false);
    } finally {
      setRosterLoading(false);
    }
  };

  const handleDeleteCourse = async () => {
    if (!deleteTarget) return;
    try {
      const res = await axiosClient.delete(`/courses.php?id=${deleteTarget.id}`);
      if (res.success) {
        showAlert('Course deleted successfully', 'success');
        setDeleteTarget(null);
        fetchCourses();
      }
    } catch (err) {
      showAlert(err.message, 'error');
    }
  };

  return (
    <div className="fade-in">
      {/* Header */}
      <div className="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
        <div>
          <h3 className="fw-bold mb-1">Course Catalog & Curriculum</h3>
          <p className="text-muted mb-0">Manage course offerings, credit allocations, and faculty instructors.</p>
        </div>
        {role === 'admin' && <button className="btn btn-primary d-flex align-items-center gap-2" onClick={handleOpenAdd}>
          <i className="bi bi-journal-plus"></i>
          <span>Create New Course</span>
        </button>}
      </div>

      {/* Filter and Search Bar */}
      <div className="card custom-table-card p-3 mb-4">
        <div className="row g-3">
          <div className="col-12 col-md-7">
            <div className="input-group">
              <span className="input-group-text bg-light border-end-0">
                <i className="bi bi-search text-muted"></i>
              </span>
              <input
                type="text"
                className="form-control border-start-0 bg-light"
                placeholder="Search course title, code (e.g. CS101), or instructor..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </div>
          </div>
          <div className="col-12 col-md-5">
            <select
              className="form-select"
              value={departmentFilter}
              onChange={(e) => setDepartmentFilter(e.target.value)}
            >
              <option value="All">All Departments</option>
              {departments.map((d) => (
                <option key={d} value={d}>{d}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Courses Cards Grid */}
      <div className="row g-4 mb-4">
        {loading ? (
          <div className="col-12 text-center py-5">
            <div className="spinner-border text-primary" role="status"></div>
            <div className="text-muted mt-2">Loading courses...</div>
          </div>
        ) : courses.length === 0 ? (
          <div className="col-12 text-center py-5 text-muted">
            <i className="bi bi-journal-x fs-1 d-block mb-2 text-secondary"></i>
            No courses found matching your criteria.
          </div>
        ) : (
          courses.map((c) => (
            <div key={c.id} className="col-12 col-md-6 col-xl-4">
              <div className="card h-100 border-0 stat-card p-3 d-flex flex-column justify-content-between">
                <div>
                  <div className="d-flex justify-content-between align-items-start mb-2">
                    <span className="badge bg-primary-subtle text-primary border border-primary-subtle font-monospace fs-7">
                      {c.course_code}
                    </span>
                    <span className="badge bg-light text-secondary border">
                      {c.credits} Credits &bull; Sem {c.semester}
                    </span>
                  </div>

                  <h5 className="fw-bold text-dark mb-1">{c.title}</h5>
                  <p className="text-muted small mb-3" style={{ minHeight: '40px', lineHeight: '1.4' }}>
                    {c.description || 'No detailed syllabus description provided.'}
                  </p>

                  <div className="p-2.5 bg-light rounded-3 mb-3 small">
                    <div className="d-flex align-items-center gap-2 mb-1">
                      <i className="bi bi-person-workspace text-primary"></i>
                      <span className="fw-medium text-dark">{c.instructor_name}</span>
                    </div>
                    <div className="d-flex align-items-center gap-2 text-muted">
                      <i className="bi bi-building"></i>
                      <span>{c.department}</span>
                    </div>
                  </div>
                </div>

                <div className="pt-2 border-top d-flex justify-content-between align-items-center">
                  <button
                    className="btn btn-sm btn-outline-primary d-flex align-items-center gap-1.5"
                    onClick={() => handleOpenRoster(c.id)}
                  >
                    <i className="bi bi-people"></i>
                    <span>{c.enrolled_count || 0} Enrolled</span>
                  </button>

                  {role === 'admin' && (
                    <div className="btn-group btn-group-sm">
                      <button
                        className="btn btn-outline-secondary"
                        title="Edit Course"
                        onClick={() => handleOpenEdit(c)}
                      >
                        <i className="bi bi-pencil"></i>
                      </button>
                      <button
                        className="btn btn-outline-danger"
                        title="Delete Course"
                        onClick={() => setDeleteTarget(c)}
                      >
                        <i className="bi bi-trash"></i>
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* CREATE / EDIT COURSE MODAL */}
      {showModal && (
        <div className="modal show d-block" tabIndex="-1" style={{ backgroundColor: 'rgba(0,0,0,0.5)' }}>
          <div className="modal-dialog modal-md modal-dialog-centered">
            <div className="modal-content">
              <form onSubmit={handleSaveCourse}>
                <div className="modal-header">
                  <h5 className="modal-title fw-bold">
                    <i className="bi bi-journal-check text-primary me-2"></i>
                    {editingCourse ? 'Edit Course Offering' : 'Create Course Offering'}
                  </h5>
                  <button type="button" className="btn-close" onClick={() => setShowModal(false)}></button>
                </div>
                <div className="modal-body p-4">
                  <div className="row g-3">
                    <div className="col-md-5">
                      <label className="form-label small fw-semibold">Course Code *</label>
                      <input
                        type="text"
                        className="form-control"
                        placeholder="e.g. CS101"
                        required
                        value={formData.course_code}
                        onChange={(e) => setFormData({ ...formData, course_code: e.target.value })}
                      />
                    </div>
                    <div className="col-md-7">
                      <label className="form-label small fw-semibold">Credits *</label>
                      <input
                        type="number"
                        className="form-control"
                        min="1"
                        max="8"
                        required
                        value={formData.credits}
                        onChange={(e) => setFormData({ ...formData, credits: parseInt(e.target.value) })}
                      />
                    </div>
                    <div className="col-12">
                      <label className="form-label small fw-semibold">Course Title *</label>
                      <input
                        type="text"
                        className="form-control"
                        placeholder="e.g. Distributed Operating Systems"
                        required
                        value={formData.title}
                        onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                      />
                    </div>
                    <div className="col-md-6">
                      <label className="form-label small fw-semibold">Department *</label>
                      <select
                        className="form-select"
                        value={formData.department}
                        onChange={(e) => setFormData({ ...formData, department: e.target.value })}
                      >
                        {departments.map((d) => (
                          <option key={d} value={d}>{d}</option>
                        ))}
                      </select>
                    </div>
                    <div className="col-md-6">
                      <label className="form-label small fw-semibold">Semester *</label>
                      <select
                        className="form-select"
                        value={formData.semester}
                        onChange={(e) => setFormData({ ...formData, semester: parseInt(e.target.value) })}
                      >
                        {[1, 2, 3, 4, 5, 6, 7, 8].map((s) => (
                          <option key={s} value={s}>{s}</option>
                        ))}
                      </select>
                    </div>
                    <div className="col-12">
                      <label className="form-label small fw-semibold">Instructor Name *</label>
                      <input
                        type="text"
                        className="form-control"
                        placeholder="e.g. Dr. Rajesh Khanna"
                        required
                        value={formData.instructor_name}
                        onChange={(e) => setFormData({ ...formData, instructor_name: e.target.value })}
                      />
                    </div>
                    <div className="col-12">
                      <label className="form-label small fw-semibold">Course Syllabus / Description</label>
                      <textarea
                        className="form-control"
                        rows="3"
                        placeholder="Brief overview of curriculum topics..."
                        value={formData.description}
                        onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                      ></textarea>
                    </div>
                  </div>
                </div>
                <div className="modal-footer">
                  <button type="button" className="btn btn-light" onClick={() => setShowModal(false)}>Cancel</button>
                  <button type="submit" className="btn btn-primary">
                    <i className="bi bi-save me-1"></i> {editingCourse ? 'Update Course' : 'Save Course'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* COURSE ROSTER MODAL */}
      {showRosterModal && (
        <div className="modal show d-block" tabIndex="-1" style={{ backgroundColor: 'rgba(0,0,0,0.5)' }}>
          <div className="modal-dialog modal-lg modal-dialog-centered">
            <div className="modal-content">
              <div className="modal-header">
                <div>
                  <h5 className="modal-title fw-bold mb-0">Course Class Roster</h5>
                  {selectedCourseRoster && (
                    <small className="text-muted">
                      {selectedCourseRoster.course_code} - {selectedCourseRoster.title}
                    </small>
                  )}
                </div>
                <button type="button" className="btn-close" onClick={() => setShowRosterModal(false)}></button>
              </div>
              <div className="modal-body p-4">
                {rosterLoading || !selectedCourseRoster ? (
                  <div className="text-center py-4">
                    <div className="spinner-border text-primary" role="status"></div>
                  </div>
                ) : (
                  <div>
                    <div className="d-flex justify-content-between align-items-center mb-3">
                      <span className="fw-semibold small text-muted">
                        Total Enrolled: {selectedCourseRoster.enrolled_students?.length || 0} Students
                      </span>
                    </div>

                    <div className="table-responsive">
                      <table className="table table-hover align-middle mb-0">
                        <thead className="table-light">
                          <tr>
                            <th>Student</th>
                            <th>Roll Code</th>
                            <th>Email</th>
                            <th>Department</th>
                            <th>Status</th>
                            <th>Grade</th>
                          </tr>
                        </thead>
                        <tbody>
                          {(!selectedCourseRoster.enrolled_students || selectedCourseRoster.enrolled_students.length === 0) ? (
                            <tr>
                              <td colSpan="6" className="text-center py-4 text-muted">
                                No students enrolled in this course yet.
                              </td>
                            </tr>
                          ) : (
                            selectedCourseRoster.enrolled_students.map((s) => (
                              <tr key={s.enrollment_id}>
                                <td className="fw-semibold text-dark">{s.student_name}</td>
                                <td><span className="badge bg-light text-dark border">{s.student_code}</span></td>
                                <td className="small text-muted">{s.email}</td>
                                <td>{s.department}</td>
                                <td>
                                  <span className={`badge ${s.status === 'Completed' ? 'bg-success' : s.status === 'Dropped' ? 'bg-danger' : 'bg-primary'}`}>
                                    {s.status}
                                  </span>
                                </td>
                                <td>
                                  <span className="badge bg-light text-secondary border">
                                    {s.grade || 'Pending'}
                                  </span>
                                </td>
                              </tr>
                            ))
                          )}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}
              </div>
              <div className="modal-footer">
                <button type="button" className="btn btn-secondary" onClick={() => setShowRosterModal(false)}>Close</button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* DELETE CONFIRM MODAL */}
      {deleteTarget && (
        <div className="modal show d-block" tabIndex="-1" style={{ backgroundColor: 'rgba(0,0,0,0.5)' }}>
          <div className="modal-dialog modal-dialog-centered">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title fw-bold text-danger">Delete Course Offering</h5>
                <button type="button" className="btn-close" onClick={() => setDeleteTarget(null)}></button>
              </div>
              <div className="modal-body">
                <p>Are you sure you want to delete course <strong>{deleteTarget.title} ({deleteTarget.course_code})</strong>?</p>
                <small className="text-muted">Existing student enrollments and attendance records for this subject will be removed.</small>
              </div>
              <div className="modal-footer">
                <button type="button" className="btn btn-light" onClick={() => setDeleteTarget(null)}>Cancel</button>
                <button type="button" className="btn btn-danger" onClick={handleDeleteCourse}>Delete Course</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
