import React, { useEffect, useState } from 'react';
import axiosClient from '../api/axiosClient';

export default function Enrollments({ showAlert }) {
  const [enrollments, setEnrollments] = useState([]);
  const [students, setStudents] = useState([]);
  const [courses, setCourses] = useState([]);
  const [loading, setLoading] = useState(true);

  // Filters
  const [statusFilter, setStatusFilter] = useState('All');
  const [courseFilter, setCourseFilter] = useState('All');

  // Modals
  const [showAddModal, setShowAddModal] = useState(false);
  const [addForm, setAddForm] = useState({
    student_id: '',
    course_id: '',
    enrollment_date: new Date().toISOString().split('T')[0],
    status: 'Enrolled',
    grade: 'Pending'
  });

  const [editItem, setEditItem] = useState(null);
  const [editGrade, setEditGrade] = useState('Pending');
  const [editStatus, setEditStatus] = useState('Enrolled');

  const [deleteTarget, setDeleteTarget] = useState(null);

  const fetchDropdowns = async () => {
    try {
      const [stuRes, courseRes] = await Promise.all([
        axiosClient.get('/students.php'),
        axiosClient.get('/courses.php')
      ]);
      if (stuRes.success) setStudents(stuRes.data);
      if (courseRes.success) setCourses(courseRes.data);
    } catch (err) {
      showAlert(err.message, 'error');
    }
  };

  const fetchEnrollments = async () => {
    try {
      setLoading(true);
      const params = {};
      if (statusFilter !== 'All') params.status = statusFilter;
      if (courseFilter !== 'All') params.course_id = courseFilter;

      const res = await axiosClient.get('/enrollments.php', { params });
      if (res.success) {
        setEnrollments(res.data);
      }
    } catch (err) {
      showAlert(err.message, 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDropdowns();
  }, []);

  useEffect(() => {
    fetchEnrollments();
  }, [statusFilter, courseFilter]);

  const handleOpenAdd = () => {
    setAddForm({
      student_id: students[0]?.id || '',
      course_id: courses[0]?.id || '',
      enrollment_date: new Date().toISOString().split('T')[0],
      status: 'Enrolled',
      grade: 'Pending'
    });
    setShowAddModal(true);
  };

  const handleSaveEnrollment = async (e) => {
    e.preventDefault();
    try {
      const res = await axiosClient.post('/enrollments.php', addForm);
      if (res.success) {
        showAlert('Student successfully enrolled', 'success');
        setShowAddModal(false);
        fetchEnrollments();
      }
    } catch (err) {
      showAlert(err.message, 'error');
    }
  };

  const handleOpenGradeEdit = (item) => {
    setEditItem(item);
    setEditGrade(item.grade || 'Pending');
    setEditStatus(item.status || 'Enrolled');
  };

  const handleSaveGradeEdit = async (e) => {
    e.preventDefault();
    if (!editItem) return;
    try {
      const res = await axiosClient.put('/enrollments.php', {
        id: editItem.id,
        grade: editGrade,
        status: editStatus
      });
      if (res.success) {
        showAlert('Grade & status updated', 'success');
        setEditItem(null);
        fetchEnrollments();
      }
    } catch (err) {
      showAlert(err.message, 'error');
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    try {
      const res = await axiosClient.delete(`/enrollments.php?id=${deleteTarget.id}`);
      if (res.success) {
        showAlert('Enrollment record removed', 'success');
        setDeleteTarget(null);
        fetchEnrollments();
      }
    } catch (err) {
      showAlert(err.message, 'error');
    }
  };

  return (
    <div className="fade-in">
      {/* Header */}
      <div className="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
        <div>
          <h3 className="fw-bold mb-1">Course Enrollments & Grading</h3>
          <p className="text-muted mb-0">Track course assignments, completion progress, and academic letter grades.</p>
        </div>
        <button className="btn btn-primary d-flex align-items-center gap-2" onClick={handleOpenAdd}>
          <i className="bi bi-plus-circle-fill"></i>
          <span>Enroll Student</span>
        </button>
      </div>

      {/* Filter Bar */}
      <div className="card custom-table-card p-3 mb-4">
        <div className="row g-3">
          <div className="col-12 col-md-6">
            <select
              className="form-select"
              value={courseFilter}
              onChange={(e) => setCourseFilter(e.target.value)}
            >
              <option value="All">Filter by All Courses</option>
              {courses.map((c) => (
                <option key={c.id} value={c.id}>{c.course_code} - {c.title}</option>
              ))}
            </select>
          </div>
          <div className="col-12 col-md-6">
            <select
              className="form-select"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
            >
              <option value="All">All Enrollment Statuses</option>
              <option value="Enrolled">Enrolled</option>
              <option value="Completed">Completed</option>
              <option value="Dropped">Dropped</option>
            </select>
          </div>
        </div>
      </div>

      {/* Enrollments Table */}
      <div className="card custom-table-card">
        <div className="table-responsive">
          <table className="table table-hover align-middle mb-0">
            <thead>
              <tr>
                <th>Student</th>
                <th>Roll Code</th>
                <th>Course</th>
                <th>Instructor</th>
                <th>Enrollment Date</th>
                <th>Status</th>
                <th>Grade</th>
                <th className="text-end">Actions</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr>
                  <td colSpan="8" className="text-center py-5">
                    <div className="spinner-border spinner-border-sm text-primary me-2"></div>
                    <span className="text-muted">Loading enrollment records...</span>
                  </td>
                </tr>
              ) : enrollments.length === 0 ? (
                <tr>
                  <td colSpan="8" className="text-center py-5 text-muted">
                    <i className="bi bi-card-checklist fs-1 d-block mb-2 text-secondary"></i>
                    No enrollment records match current filters.
                  </td>
                </tr>
              ) : (
                enrollments.map((item) => (
                  <tr key={item.id}>
                    <td>
                      <div className="fw-semibold text-dark">{item.student_name}</div>
                      <div className="text-muted small">{item.student_department}</div>
                    </td>
                    <td>
                      <span className="badge bg-light text-secondary border font-monospace">
                        {item.student_code}
                      </span>
                    </td>
                    <td>
                      <div>
                        <span className="fw-medium">{item.course_title}</span>
                        <small className="text-muted ms-1">({item.course_code})</small>
                      </div>
                    </td>
                    <td className="text-muted small">{item.instructor_name}</td>
                    <td className="text-muted small">{item.enrollment_date}</td>
                    <td>
                      <span className={`badge ${item.status === 'Completed' ? 'bg-success-subtle text-success border border-success-subtle' : item.status === 'Dropped' ? 'bg-danger-subtle text-danger border border-danger-subtle' : 'bg-primary-subtle text-primary border border-primary-subtle'}`}>
                        {item.status}
                      </span>
                    </td>
                    <td>
                      <span className={`badge fs-7 ${item.grade === 'A+' || item.grade === 'A' ? 'bg-success' : item.grade === 'F' ? 'bg-danger' : 'bg-light text-dark border'}`}>
                        {item.grade || 'Pending'}
                      </span>
                    </td>
                    <td className="text-end">
                      <div className="btn-group btn-group-sm">
                        <button
                          className="btn btn-outline-primary"
                          title="Assign or Update Grade"
                          onClick={() => handleOpenGradeEdit(item)}
                        >
                          <i className="bi bi-pencil-square me-1"></i> Grade
                        </button>
                        <button
                          className="btn btn-outline-danger"
                          title="Drop/Remove Enrollment"
                          onClick={() => setDeleteTarget(item)}
                        >
                          <i className="bi bi-trash"></i>
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* ENROLL STUDENT MODAL */}
      {showAddModal && (
        <div className="modal show d-block" tabIndex="-1" style={{ backgroundColor: 'rgba(0,0,0,0.5)' }}>
          <div className="modal-dialog modal-md modal-dialog-centered">
            <div className="modal-content">
              <form onSubmit={handleSaveEnrollment}>
                <div className="modal-header">
                  <h5 className="modal-title fw-bold">Enroll Student in Course</h5>
                  <button type="button" className="btn-close" onClick={() => setShowAddModal(false)}></button>
                </div>
                <div className="modal-body p-4">
                  <div className="mb-3">
                    <label className="form-label small fw-semibold">Select Student *</label>
                    <select
                      className="form-select"
                      required
                      value={addForm.student_id}
                      onChange={(e) => setAddForm({ ...addForm, student_id: e.target.value })}
                    >
                      <option value="">-- Choose Student --</option>
                      {students.map((s) => (
                        <option key={s.id} value={s.id}>
                          {s.first_name} {s.last_name} ({s.student_code}) - {s.department}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div className="mb-3">
                    <label className="form-label small fw-semibold">Select Course *</label>
                    <select
                      className="form-select"
                      required
                      value={addForm.course_id}
                      onChange={(e) => setAddForm({ ...addForm, course_id: e.target.value })}
                    >
                      <option value="">-- Choose Course --</option>
                      {courses.map((c) => (
                        <option key={c.id} value={c.id}>
                          {c.course_code} - {c.title} ({c.credits} Credits)
                        </option>
                      ))}
                    </select>
                  </div>
                  <div className="row g-3">
                    <div className="col-md-6">
                      <label className="form-label small fw-semibold">Enrollment Date</label>
                      <input
                        type="date"
                        className="form-control"
                        value={addForm.enrollment_date}
                        onChange={(e) => setAddForm({ ...addForm, enrollment_date: e.target.value })}
                      />
                    </div>
                    <div className="col-md-6">
                      <label className="form-label small fw-semibold">Initial Status</label>
                      <select
                        className="form-select"
                        value={addForm.status}
                        onChange={(e) => setAddForm({ ...addForm, status: e.target.value })}
                      >
                        <option value="Enrolled">Enrolled</option>
                        <option value="Completed">Completed</option>
                        <option value="Dropped">Dropped</option>
                      </select>
                    </div>
                  </div>
                </div>
                <div className="modal-footer">
                  <button type="button" className="btn btn-light" onClick={() => setShowAddModal(false)}>Cancel</button>
                  <button type="submit" className="btn btn-primary">Confirm Enrollment</button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* UPDATE GRADE & STATUS MODAL */}
      {editItem && (
        <div className="modal show d-block" tabIndex="-1" style={{ backgroundColor: 'rgba(0,0,0,0.5)' }}>
          <div className="modal-dialog modal-dialog-centered">
            <div className="modal-content">
              <form onSubmit={handleSaveGradeEdit}>
                <div className="modal-header">
                  <h5 className="modal-title fw-bold">Update Grade & Academic Status</h5>
                  <button type="button" className="btn-close" onClick={() => setEditItem(null)}></button>
                </div>
                <div className="modal-body p-4">
                  <div className="p-3 bg-light rounded-3 mb-3">
                    <div className="fw-semibold text-dark">{editItem.student_name}</div>
                    <div className="text-muted small">{editItem.course_code}: {editItem.course_title}</div>
                  </div>

                  <div className="row g-3">
                    <div className="col-md-6">
                      <label className="form-label small fw-semibold">Letter Grade</label>
                      <select
                        className="form-select"
                        value={editGrade}
                        onChange={(e) => setEditGrade(e.target.value)}
                      >
                        <option value="Pending">Pending</option>
                        <option value="A+">A+ (Distinction)</option>
                        <option value="A">A (Excellent)</option>
                        <option value="B+">B+ (Very Good)</option>
                        <option value="B">B (Good)</option>
                        <option value="C">C (Average)</option>
                        <option value="D">D (Pass)</option>
                        <option value="F">F (Fail)</option>
                      </select>
                    </div>
                    <div className="col-md-6">
                      <label className="form-label small fw-semibold">Enrollment Status</label>
                      <select
                        className="form-select"
                        value={editStatus}
                        onChange={(e) => setEditStatus(e.target.value)}
                      >
                        <option value="Enrolled">Enrolled</option>
                        <option value="Completed">Completed</option>
                        <option value="Dropped">Dropped</option>
                      </select>
                    </div>
                  </div>
                </div>
                <div className="modal-footer">
                  <button type="button" className="btn btn-light" onClick={() => setEditItem(null)}>Cancel</button>
                  <button type="submit" className="btn btn-primary">Save Grade</button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* REMOVE ENROLLMENT MODAL */}
      {deleteTarget && (
        <div className="modal show d-block" tabIndex="-1" style={{ backgroundColor: 'rgba(0,0,0,0.5)' }}>
          <div className="modal-dialog modal-dialog-centered">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title fw-bold text-danger">Remove Enrollment</h5>
                <button type="button" className="btn-close" onClick={() => setDeleteTarget(null)}></button>
              </div>
              <div className="modal-body">
                <p>Remove enrollment for <strong>{deleteTarget.student_name}</strong> from <strong>{deleteTarget.course_title}</strong>?</p>
              </div>
              <div className="modal-footer">
                <button type="button" className="btn btn-light" onClick={() => setDeleteTarget(null)}>Cancel</button>
                <button type="button" className="btn btn-danger" onClick={handleDelete}>Remove</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
