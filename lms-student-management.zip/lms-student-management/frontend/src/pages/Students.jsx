import React, { useEffect, useState } from 'react';
import axiosClient from '../api/axiosClient';

const INITIAL_FORM = {
  student_code: '',
  first_name: '',
  last_name: '',
  email: '',
  phone: '',
  gender: 'Male',
  dob: '2004-01-01',
  department: 'Computer Science',
  semester: 1,
  status: 'Active',
  address: ''
};

export default function Students({ showAlert }) {
  const [students, setStudents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [departmentFilter, setDepartmentFilter] = useState('All');
  const [statusFilter, setStatusFilter] = useState('All');

  // Modals state
  const [showFormModal, setShowFormModal] = useState(false);
  const [editingStudent, setEditingStudent] = useState(null);
  const [formData, setFormData] = useState(INITIAL_FORM);

  const [showProfileModal, setShowProfileModal] = useState(false);
  const [selectedProfile, setSelectedProfile] = useState(null);
  const [profileLoading, setProfileLoading] = useState(false);

  const [deleteTarget, setDeleteTarget] = useState(null);

  const departments = [
    'Computer Science',
    'Information Technology',
    'Data Science',
    'Electrical Engineering',
    'Mechanical Engineering',
    'Civil Engineering'
  ];

  const fetchStudents = async () => {
    try {
      setLoading(true);
      const params = {};
      if (search.trim()) params.search = search.trim();
      if (departmentFilter !== 'All') params.department = departmentFilter;
      if (statusFilter !== 'All') params.status = statusFilter;

      const res = await axiosClient.get('/students.php', { params });
      if (res.success) {
        setStudents(res.data);
      }
    } catch (err) {
      showAlert(err.message, 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const timer = setTimeout(() => {
      fetchStudents();
    }, 300);
    return () => clearTimeout(timer);
  }, [search, departmentFilter, statusFilter]);

  const handleOpenAdd = () => {
    setEditingStudent(null);
    setFormData({
      ...INITIAL_FORM,
      student_code: `STU-2026-${String(Math.floor(100 + Math.random() * 900))}`
    });
    setShowFormModal(true);
  };

  const handleOpenEdit = (student) => {
    setEditingStudent(student);
    setFormData({
      id: student.id,
      student_code: student.student_code,
      first_name: student.first_name,
      last_name: student.last_name,
      email: student.email,
      phone: student.phone,
      gender: student.gender,
      dob: student.dob,
      department: student.department,
      semester: student.semester,
      status: student.status,
      address: student.address || ''
    });
    setShowFormModal(true);
  };

  const handleSaveStudent = async (e) => {
    e.preventDefault();
    try {
      if (editingStudent) {
        const res = await axiosClient.put('/students.php', formData);
        if (res.success) {
          showAlert('Student profile updated successfully', 'success');
        }
      } else {
        const res = await axiosClient.post('/students.php', formData);
        if (res.success) {
          showAlert('Student registered successfully', 'success');
        }
      }
      setShowFormModal(false);
      fetchStudents();
    } catch (err) {
      showAlert(err.message, 'error');
    }
  };

  const handleOpenProfile = async (id) => {
    setShowProfileModal(true);
    setProfileLoading(true);
    try {
      const res = await axiosClient.get(`/students.php?id=${id}`);
      if (res.success) {
        setSelectedProfile(res.data);
      }
    } catch (err) {
      showAlert(err.message, 'error');
      setShowProfileModal(false);
    } finally {
      setProfileLoading(false);
    }
  };

  const handleDeleteStudent = async () => {
    if (!deleteTarget) return;
    try {
      const res = await axiosClient.delete(`/students.php?id=${deleteTarget.id}`);
      if (res.success) {
        showAlert('Student removed successfully', 'success');
        setDeleteTarget(null);
        fetchStudents();
      }
    } catch (err) {
      showAlert(err.message, 'error');
    }
  };

  return (
    <div className="fade-in">
      {/* Header */}
      <div className="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
        <div>
          <h3 className="fw-bold mb-1">Students Directory</h3>
          <p className="text-muted mb-0">Manage student profiles, enrollments, credentials, and academic status.</p>
        </div>
        <button className="btn btn-primary d-flex align-items-center gap-2" onClick={handleOpenAdd}>
          <i className="bi bi-person-plus-fill"></i>
          <span>Add New Student</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="card custom-table-card p-3 mb-4">
        <div className="row g-3">
          <div className="col-12 col-md-5">
            <div className="input-group">
              <span className="input-group-text bg-light border-end-0">
                <i className="bi bi-search text-muted"></i>
              </span>
              <input
                type="text"
                className="form-control border-start-0 bg-light"
                placeholder="Search by student name, roll code, or email..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </div>
          </div>
          <div className="col-12 col-sm-6 col-md-4">
            <select
              className="form-select"
              value={departmentFilter}
              onChange={(e) => setDepartmentFilter(e.target.value)}
            >
              <option value="All">All Departments</option>
              {departments.map((d) => (
                <option key={d} value={d}>{d}</option>
              ))}
            </select>
          </div>
          <div className="col-12 col-sm-6 col-md-3">
            <select
              className="form-select"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
            >
              <option value="All">All Statuses</option>
              <option value="Active">Active</option>
              <option value="Inactive">Inactive</option>
              <option value="Suspended">Suspended</option>
            </select>
          </div>
        </div>
      </div>

      {/* Students Table */}
      <div className="card custom-table-card">
        <div className="table-responsive">
          <table className="table table-hover align-middle mb-0">
            <thead>
              <tr>
                <th>Student</th>
                <th>Roll Code</th>
                <th>Department</th>
                <th>Semester</th>
                <th>Contact</th>
                <th>Status</th>
                <th>Enrolled</th>
                <th className="text-end">Actions</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr>
                  <td colSpan="8" className="text-center py-5">
                    <div className="spinner-border spinner-border-sm text-primary me-2"></div>
                    <span className="text-muted">Loading student directory...</span>
                  </td>
                </tr>
              ) : students.length === 0 ? (
                <tr>
                  <td colSpan="8" className="text-center py-5 text-muted">
                    <i className="bi bi-person-x fs-1 d-block mb-2 text-secondary"></i>
                    No students match the current filters.
                  </td>
                </tr>
              ) : (
                students.map((stu) => (
                  <tr key={stu.id}>
                    <td>
                      <div className="d-flex align-items-center gap-2">
                        <div 
                          className="rounded-circle bg-primary-subtle text-primary fw-bold d-flex align-items-center justify-content-center"
                          style={{ width: '38px', height: '38px', fontSize: '0.85rem' }}
                        >
                          {stu.first_name[0]}{stu.last_name[0]}
                        </div>
                        <div>
                          <div className="fw-semibold text-dark">{stu.first_name} {stu.last_name}</div>
                          <div className="text-muted small">{stu.gender} &bull; {stu.dob}</div>
                        </div>
                      </div>
                    </td>
                    <td>
                      <span className="badge bg-light text-secondary border font-monospace">
                        {stu.student_code}
                      </span>
                    </td>
                    <td><span className="fw-medium">{stu.department}</span></td>
                    <td>Sem {stu.semester}</td>
                    <td>
                      <div className="small">
                        <div><i className="bi bi-envelope me-1 text-muted"></i>{stu.email}</div>
                        <div><i className="bi bi-telephone me-1 text-muted"></i>{stu.phone}</div>
                      </div>
                    </td>
                    <td>
                      <span className={`badge ${stu.status === 'Active' ? 'bg-success-subtle text-success border border-success-subtle' : stu.status === 'Inactive' ? 'bg-warning-subtle text-warning border border-warning-subtle' : 'bg-danger-subtle text-danger border border-danger-subtle'}`}>
                        {stu.status}
                      </span>
                    </td>
                    <td>
                      <span className="badge bg-primary-subtle text-primary border border-primary-subtle">
                        {stu.enrolled_count || 0} Courses
                      </span>
                    </td>
                    <td className="text-end">
                      <div className="btn-group btn-group-sm">
                        <button
                          className="btn btn-outline-info"
                          title="View Profile & Grades"
                          onClick={() => handleOpenProfile(stu.id)}
                        >
                          <i className="bi bi-eye"></i>
                        </button>
                        <button
                          className="btn btn-outline-primary"
                          title="Edit Student"
                          onClick={() => handleOpenEdit(stu)}
                        >
                          <i className="bi bi-pencil-square"></i>
                        </button>
                        <button
                          className="btn btn-outline-danger"
                          title="Delete Student"
                          onClick={() => setDeleteTarget(stu)}
                        >
                          <i className="bi bi-trash"></i>
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* ADD / EDIT MODAL */}
      {showFormModal && (
        <div className="modal show d-block" tabIndex="-1" style={{ backgroundColor: 'rgba(0,0,0,0.5)' }}>
          <div className="modal-dialog modal-lg modal-dialog-centered">
            <div className="modal-content">
              <form onSubmit={handleSaveStudent}>
                <div className="modal-header">
                  <h5 className="modal-title fw-bold">
                    <i className={`bi ${editingStudent ? 'bi-pencil-square text-primary' : 'bi-person-plus-fill text-success'} me-2`}></i>
                    {editingStudent ? 'Edit Student Details' : 'Register New Student'}
                  </h5>
                  <button type="button" className="btn-close" onClick={() => setShowFormModal(false)}></button>
                </div>
                <div className="modal-body p-4">
                  <div className="row g-3">
                    <div className="col-md-6">
                      <label className="form-label small fw-semibold">Student Roll Code *</label>
                      <input
                        type="text"
                        className="form-control"
                        required
                        value={formData.student_code}
                        onChange={(e) => setFormData({ ...formData, student_code: e.target.value })}
                      />
                    </div>
                    <div className="col-md-3">
                      <label className="form-label small fw-semibold">First Name *</label>
                      <input
                        type="text"
                        className="form-control"
                        required
                        value={formData.first_name}
                        onChange={(e) => setFormData({ ...formData, first_name: e.target.value })}
                      />
                    </div>
                    <div className="col-md-3">
                      <label className="form-label small fw-semibold">Last Name *</label>
                      <input
                        type="text"
                        className="form-control"
                        required
                        value={formData.last_name}
                        onChange={(e) => setFormData({ ...formData, last_name: e.target.value })}
                      />
                    </div>
                    <div className="col-md-6">
                      <label className="form-label small fw-semibold">Email Address *</label>
                      <input
                        type="email"
                        className="form-control"
                        required
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      />
                    </div>
                    <div className="col-md-6">
                      <label className="form-label small fw-semibold">Phone Number *</label>
                      <input
                        type="tel"
                        className="form-control"
                        required
                        value={formData.phone}
                        onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      />
                    </div>
                    <div className="col-md-4">
                      <label className="form-label small fw-semibold">Department *</label>
                      <select
                        className="form-select"
                        value={formData.department}
                        onChange={(e) => setFormData({ ...formData, department: e.target.value })}
                      >
                        {departments.map((dept) => (
                          <option key={dept} value={dept}>{dept}</option>
                        ))}
                      </select>
                    </div>
                    <div className="col-md-2">
                      <label className="form-label small fw-semibold">Semester *</label>
                      <select
                        className="form-select"
                        value={formData.semester}
                        onChange={(e) => setFormData({ ...formData, semester: parseInt(e.target.value) })}
                      >
                        {[1, 2, 3, 4, 5, 6, 7, 8].map((s) => (
                          <option key={s} value={s}>{s}</option>
                        ))}
                      </select>
                    </div>
                    <div className="col-md-3">
                      <label className="form-label small fw-semibold">Date of Birth *</label>
                      <input
                        type="date"
                        className="form-control"
                        required
                        value={formData.dob}
                        onChange={(e) => setFormData({ ...formData, dob: e.target.value })}
                      />
                    </div>
                    <div className="col-md-3">
                      <label className="form-label small fw-semibold">Gender</label>
                      <select
                        className="form-select"
                        value={formData.gender}
                        onChange={(e) => setFormData({ ...formData, gender: e.target.value })}
                      >
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                        <option value="Other">Other</option>
                      </select>
                    </div>
                    <div className="col-md-4">
                      <label className="form-label small fw-semibold">Enrollment Status</label>
                      <select
                        className="form-select"
                        value={formData.status}
                        onChange={(e) => setFormData({ ...formData, status: e.target.value })}
                      >
                        <option value="Active">Active</option>
                        <option value="Inactive">Inactive</option>
                        <option value="Suspended">Suspended</option>
                      </select>
                    </div>
                    <div className="col-md-8">
                      <label className="form-label small fw-semibold">Residential Address</label>
                      <input
                        type="text"
                        className="form-control"
                        placeholder="Street, City, Postal Code"
                        value={formData.address}
                        onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                      />
                    </div>
                  </div>
                </div>
                <div className="modal-footer">
                  <button type="button" className="btn btn-light" onClick={() => setShowFormModal(false)}>Cancel</button>
                  <button type="submit" className="btn btn-primary">
                    <i className="bi bi-check2-circle me-1"></i>
                    {editingStudent ? 'Save Changes' : 'Register Student'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* STUDENT PROFILE & GRADES MODAL */}
      {showProfileModal && (
        <div className="modal show d-block" tabIndex="-1" style={{ backgroundColor: 'rgba(0,0,0,0.5)' }}>
          <div className="modal-dialog modal-lg modal-dialog-centered">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title fw-bold d-flex align-items-center gap-2">
                  <i className="bi bi-person-badge-fill text-primary"></i>
                  Student Academic Profile
                </h5>
                <button type="button" className="btn-close" onClick={() => setShowProfileModal(false)}></button>
              </div>
              <div className="modal-body p-4">
                {profileLoading || !selectedProfile ? (
                  <div className="text-center py-5">
                    <div className="spinner-border text-primary" role="status"></div>
                  </div>
                ) : (
                  <div>
                    {/* Top Identity Banner */}
                    <div className="p-3 bg-light rounded-3 border d-flex flex-column flex-sm-row justify-content-between align-items-sm-center gap-3 mb-4">
                      <div className="d-flex align-items-center gap-3">
                        <div 
                          className="rounded-circle bg-primary text-white fs-4 fw-bold d-flex align-items-center justify-content-center"
                          style={{ width: '56px', height: '56px' }}
                        >
                          {selectedProfile.first_name[0]}{selectedProfile.last_name[0]}
                        </div>
                        <div>
                          <h5 className="mb-0 fw-bold">{selectedProfile.first_name} {selectedProfile.last_name}</h5>
                          <span className="text-muted small">{selectedProfile.email} &bull; {selectedProfile.phone}</span>
                        </div>
                      </div>
                      <div className="text-sm-end">
                        <span className="badge bg-light text-dark border font-monospace fs-6">{selectedProfile.student_code}</span>
                        <div className="text-muted small mt-1">{selectedProfile.department} &bull; Sem {selectedProfile.semester}</div>
                      </div>
                    </div>

                    {/* Attendance Summary Strip */}
                    <div className="card border p-3 mb-4 bg-white shadow-sm">
                      <div className="d-flex justify-content-between align-items-center mb-2">
                        <span className="fw-semibold small text-muted text-uppercase">Attendance Performance</span>
                        <span className="badge bg-success-subtle text-success fs-7 fw-bold">
                          {selectedProfile.attendance_stats?.percentage}% Overall
                        </span>
                      </div>
                      <div className="row text-center g-2 pt-1">
                        <div className="col-3 border-end">
                          <div className="fs-6 fw-bold">{selectedProfile.attendance_stats?.total_classes || 0}</div>
                          <div className="text-muted small">Total Sessions</div>
                        </div>
                        <div className="col-3 border-end">
                          <div className="fs-6 fw-bold text-success">{selectedProfile.attendance_stats?.present || 0}</div>
                          <div className="text-muted small">Present</div>
                        </div>
                        <div className="col-3 border-end">
                          <div className="fs-6 fw-bold text-warning">{selectedProfile.attendance_stats?.late || 0}</div>
                          <div className="text-muted small">Late</div>
                        </div>
                        <div className="col-3">
                          <div className="fs-6 fw-bold text-danger">{selectedProfile.attendance_stats?.absent || 0}</div>
                          <div className="text-muted small">Absent</div>
                        </div>
                      </div>
                    </div>

                    {/* Enrolled Courses & Grades */}
                    <h6 className="fw-bold mb-3 d-flex align-items-center gap-2">
                      <i className="bi bi-journals text-primary"></i>
                      Enrolled Courses ({selectedProfile.enrolled_courses?.length || 0})
                    </h6>

                    <div className="table-responsive">
                      <table className="table table-bordered table-sm align-middle mb-0">
                        <thead className="table-light">
                          <tr>
                            <th>Code</th>
                            <th>Course Title</th>
                            <th>Credits</th>
                            <th>Instructor</th>
                            <th>Status</th>
                            <th>Grade</th>
                          </tr>
                        </thead>
                        <tbody>
                          {(!selectedProfile.enrolled_courses || selectedProfile.enrolled_courses.length === 0) ? (
                            <tr>
                              <td colSpan="6" className="text-center py-3 text-muted">No enrolled courses.</td>
                            </tr>
                          ) : (
                            selectedProfile.enrolled_courses.map((c) => (
                              <tr key={c.enrollment_id}>
                                <td className="fw-semibold">{c.course_code}</td>
                                <td>{c.title}</td>
                                <td>{c.credits}</td>
                                <td>{c.instructor_name}</td>
                                <td><span className="badge bg-primary-subtle text-primary">{c.enrollment_status}</span></td>
                                <td>
                                  <span className={`badge ${c.grade === 'A+' || c.grade === 'A' ? 'bg-success' : c.grade === 'F' ? 'bg-danger' : 'bg-light text-dark border'}`}>
                                    {c.grade}
                                  </span>
                                </td>
                              </tr>
                            ))
                          )}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}
              </div>
              <div className="modal-footer">
                <button type="button" className="btn btn-secondary" onClick={() => setShowProfileModal(false)}>Close</button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* DELETE CONFIRMATION MODAL */}
      {deleteTarget && (
        <div className="modal show d-block" tabIndex="-1" style={{ backgroundColor: 'rgba(0,0,0,0.5)' }}>
          <div className="modal-dialog modal-dialog-centered">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title fw-bold text-danger">
                  <i className="bi bi-exclamation-triangle-fill me-2"></i>
                  Confirm Student Deletion
                </h5>
                <button type="button" className="btn-close" onClick={() => setDeleteTarget(null)}></button>
              </div>
              <div className="modal-body">
                <p className="mb-1">Are you sure you want to permanently remove student <strong>{deleteTarget.first_name} {deleteTarget.last_name}</strong> ({deleteTarget.student_code})?</p>
                <small className="text-muted">This will also delete their enrolled courses, grades, and attendance records according to foreign key cascading.</small>
              </div>
              <div className="modal-footer">
                <button type="button" className="btn btn-light" onClick={() => setDeleteTarget(null)}>Cancel</button>
                <button type="button" className="btn btn-danger" onClick={handleDeleteStudent}>
                  <i className="bi bi-trash me-1"></i> Delete Student
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
