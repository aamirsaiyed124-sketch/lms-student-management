import React, { useState } from 'react';
import axiosClient from '../api/axiosClient';

export default function AdminLogin({ onLogin, onBack }) {
  const [form, setForm] = useState({ username: 'admin', password: '' });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const submit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      const res = await axiosClient.post('/auth.php?action=login', { ...form, role: 'admin' });
      if (!res.success) throw new Error(res.message || 'Login failed');
      onLogin(res.data);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-vh-100 d-flex align-items-center justify-content-center bg-light p-3">
      <div className="card border-0 shadow-lg rounded-4" style={{ maxWidth: 440, width: '100%' }}>
        <div className="card-body p-4 p-md-5">
          <button className="btn btn-sm btn-light mb-3" onClick={onBack}><i className="bi bi-arrow-left me-1"></i>Back</button>
          <div className="text-center mb-4">
            <div className="bg-primary text-white rounded-circle d-inline-flex p-3 mb-3"><i className="bi bi-shield-lock-fill fs-3"></i></div>
            <h3 className="fw-bold mb-1">Admin Login</h3>
            <p className="text-muted mb-0">Administrator access</p>
          </div>

          {error && <div className="alert alert-danger py-2">{error}</div>}
          <form onSubmit={submit}>
            <label className="form-label fw-semibold">Username</label>
            <input className="form-control form-control-lg mb-3" value={form.username} onChange={e => setForm({ ...form, username: e.target.value })} required />
            <label className="form-label fw-semibold">Password</label>
            <input type="password" className="form-control form-control-lg mb-4" value={form.password} onChange={e => setForm({ ...form, password: e.target.value })} required />
            <button className="btn btn-primary btn-lg w-100" disabled={loading}>{loading ? 'Signing in...' : 'Login as Admin'}</button>
          </form>
          <div className="alert alert-light border mt-4 mb-0 small">
            Demo: <strong>admin</strong> / <strong>Admin@123</strong>
          </div>
        </div>
      </div>
    </div>
  );
}
