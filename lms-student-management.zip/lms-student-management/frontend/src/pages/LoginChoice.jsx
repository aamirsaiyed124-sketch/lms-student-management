import React from 'react';

export default function LoginChoice({ onSelect }) {
  return (
    <div className="min-vh-100 d-flex align-items-center justify-content-center bg-light p-3">
      <div className="card border-0 shadow-lg rounded-4" style={{ maxWidth: 760, width: '100%' }}>
        <div className="card-body p-4 p-md-5 text-center">
          <div className="bg-primary text-white rounded-4 d-inline-flex p-3 mb-3 shadow-sm">
            <i className="bi bi-mortarboard-fill fs-2"></i>
          </div>
          <h2 className="fw-bold mb-1">EduPulse LMS</h2>
          <p className="text-muted mb-4">Choose your login type to continue</p>

          <div className="row g-4">
            <div className="col-md-6">
              <button className="btn btn-primary w-100 p-4 rounded-4 h-100" onClick={() => onSelect('admin')}>
                <i className="bi bi-shield-lock-fill fs-1 d-block mb-2"></i>
                <span className="fs-5 fw-bold d-block">Admin Login</span>
                <small className="opacity-75">Manage students, courses, attendance and notices</small>
              </button>
            </div>
            <div className="col-md-6">
              <button className="btn btn-outline-primary w-100 p-4 rounded-4 h-100" onClick={() => onSelect('user')}>
                <i className="bi bi-person-circle fs-1 d-block mb-2"></i>
                <span className="fs-5 fw-bold d-block">User Login</span>
                <small>View dashboard, courses and notices</small>
              </button>
            </div>
          </div>

          <div className="mt-4 text-muted small">
            Student Management System • Academic Term 2026
          </div>
        </div>
      </div>
    </div>
  );
}
