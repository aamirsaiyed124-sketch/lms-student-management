import React, { useEffect, useState } from 'react';
import axiosClient from '../api/axiosClient';

const INITIAL_NOTICE = {
  title: '',
  content: '',
  priority: 'Medium',
  target_department: 'All',
  posted_by: 'Academic Office'
};

export default function Notices({ showAlert, role = 'admin' }) {
  const [notices, setNotices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [priorityFilter, setPriorityFilter] = useState('All');
  const [deptFilter, setDeptFilter] = useState('All');

  const [showModal, setShowModal] = useState(false);
  const [formData, setFormData] = useState(INITIAL_NOTICE);
  const [deleteTarget, setDeleteTarget] = useState(null);

  const departments = [
    'All',
    'Computer Science',
    'Information Technology',
    'Data Science',
    'Electrical Engineering',
    'Mechanical Engineering'
  ];

  const fetchNotices = async () => {
    try {
      setLoading(true);
      const params = {};
      if (priorityFilter !== 'All') params.priority = priorityFilter;
      if (deptFilter !== 'All') params.department = deptFilter;

      const res = await axiosClient.get('/announcements.php', { params });
      if (res.success) {
        setNotices(res.data);
      }
    } catch (err) {
      showAlert(err.message, 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchNotices();
  }, [priorityFilter, deptFilter]);

  const handleSaveNotice = async (e) => {
    e.preventDefault();
    try {
      const res = await axiosClient.post('/announcements.php', formData);
      if (res.success) {
        showAlert('Announcement published successfully', 'success');
        setShowModal(false);
        setFormData(INITIAL_NOTICE);
        fetchNotices();
      }
    } catch (err) {
      showAlert(err.message, 'error');
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    try {
      const res = await axiosClient.delete(`/announcements.php?id=${deleteTarget.id}`);
      if (res.success) {
        showAlert('Announcement deleted', 'success');
        setDeleteTarget(null);
        fetchNotices();
      }
    } catch (err) {
      showAlert(err.message, 'error');
    }
  };

  return (
    <div className="fade-in">
      {/* Header */}
      <div className="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
        <div>
          <h3 className="fw-bold mb-1">Campus Notice Board</h3>
          <p className="text-muted mb-0">Publish circulars, examination timetables, project reviews, and academic deadlines.</p>
        </div>
        {role === 'admin' && <button className="btn btn-primary d-flex align-items-center gap-2" onClick={() => setShowModal(true)}>
          <i className="bi bi-megaphone-fill"></i>
          <span>Publish Notice</span>
        </button>}
      </div>

      {/* Filter Bar */}
      <div className="card custom-table-card p-3 mb-4">
        <div className="row g-3">
          <div className="col-12 col-md-6">
            <select
              className="form-select"
              value={deptFilter}
              onChange={(e) => setDeptFilter(e.target.value)}
            >
              <option value="All">Target Department: All Departments</option>
              {departments.filter(d => d !== 'All').map((d) => (
                <option key={d} value={d}>{d}</option>
              ))}
            </select>
          </div>
          <div className="col-12 col-md-6">
            <select
              className="form-select"
              value={priorityFilter}
              onChange={(e) => setPriorityFilter(e.target.value)}
            >
              <option value="All">All Priority Levels</option>
              <option value="Urgent">Urgent</option>
              <option value="High">High</option>
              <option value="Medium">Medium</option>
              <option value="Low">Low</option>
            </select>
          </div>
        </div>
      </div>

      {/* Notices List */}
      <div className="row g-3">
        {loading ? (
          <div className="col-12 text-center py-5">
            <div className="spinner-border text-primary" role="status"></div>
            <div className="text-muted mt-2">Loading announcements...</div>
          </div>
        ) : notices.length === 0 ? (
          <div className="col-12 text-center py-5 text-muted">
            <i className="bi bi-bell-slash fs-1 d-block mb-2 text-secondary"></i>
            No announcements found.
          </div>
        ) : (
          notices.map((n) => (
            <div key={n.id} className="col-12">
              <div className="card custom-table-card p-4">
                <div className="d-flex flex-column flex-sm-row justify-content-between align-items-sm-start gap-2 mb-2">
                  <div className="d-flex align-items-center gap-2">
                    <span className={`badge ${n.priority === 'Urgent' ? 'bg-danger' : n.priority === 'High' ? 'bg-warning text-dark' : n.priority === 'Low' ? 'bg-secondary' : 'bg-primary-subtle text-primary border border-primary-subtle'}`}>
                      {n.priority} Priority
                    </span>
                    <span className="badge bg-light text-muted border">
                      Dept: {n.target_department}
                    </span>
                  </div>
                  <div className="d-flex align-items-center gap-3">
                    <span className="text-muted small">
                      <i className="bi bi-clock me-1"></i>
                      {n.created_at}
                    </span>
                    {role === 'admin' && <button
                      className="btn btn-sm btn-outline-danger border-0 p-1"
                      title="Delete Notice"
                      onClick={() => setDeleteTarget(n)}
                    >
                      <i className="bi bi-trash"></i>
                    </button>}
                  </div>
                </div>

                <h5 className="fw-bold text-dark mt-1 mb-2">{n.title}</h5>
                <p className="text-secondary mb-3" style={{ whiteSpace: 'pre-line', lineHeight: '1.6' }}>
                  {n.content}
                </p>

                <div className="pt-2 border-top d-flex justify-content-between align-items-center small text-muted">
                  <span>
                    <i className="bi bi-person-check-fill text-primary me-1"></i>
                    Published by: <strong>{n.posted_by}</strong>
                  </span>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* CREATE NOTICE MODAL */}
      {showModal && (
        <div className="modal show d-block" tabIndex="-1" style={{ backgroundColor: 'rgba(0,0,0,0.5)' }}>
          <div className="modal-dialog modal-lg modal-dialog-centered">
            <div className="modal-content">
              <form onSubmit={handleSaveNotice}>
                <div className="modal-header">
                  <h5 className="modal-title fw-bold">
                    <i className="bi bi-megaphone-fill text-primary me-2"></i>
                    Publish Academic Notice
                  </h5>
                  <button type="button" className="btn-close" onClick={() => setShowModal(false)}></button>
                </div>
                <div className="modal-body p-4">
                  <div className="row g-3">
                    <div className="col-12">
                      <label className="form-label small fw-semibold">Notice Title *</label>
                      <input
                        type="text"
                        className="form-control"
                        placeholder="e.g. Minor Project Phase 1 Progress Presentation"
                        required
                        value={formData.title}
                        onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                      />
                    </div>
                    <div className="col-md-6">
                      <label className="form-label small fw-semibold">Priority Level *</label>
                      <select
                        className="form-select"
                        value={formData.priority}
                        onChange={(e) => setFormData({ ...formData, priority: e.target.value })}
                      >
                        <option value="Low">Low</option>
                        <option value="Medium">Medium</option>
                        <option value="High">High</option>
                        <option value="Urgent">Urgent</option>
                      </select>
                    </div>
                    <div className="col-md-6">
                      <label className="form-label small fw-semibold">Target Department *</label>
                      <select
                        className="form-select"
                        value={formData.target_department}
                        onChange={(e) => setFormData({ ...formData, target_department: e.target.value })}
                      >
                        {departments.map((d) => (
                          <option key={d} value={d}>{d}</option>
                        ))}
                      </select>
                    </div>
                    <div className="col-12">
                      <label className="form-label small fw-semibold">Publisher / Designation</label>
                      <input
                        type="text"
                        className="form-control"
                        placeholder="e.g. HOD Computer Science / Project Coordinator"
                        value={formData.posted_by}
                        onChange={(e) => setFormData({ ...formData, posted_by: e.target.value })}
                      />
                    </div>
                    <div className="col-12">
                      <label className="form-label small fw-semibold">Notice Details & Instructions *</label>
                      <textarea
                        className="form-control"
                        rows="5"
                        required
                        placeholder="Enter full announcement message, dates, deadlines, room numbers, etc..."
                        value={formData.content}
                        onChange={(e) => setFormData({ ...formData, content: e.target.value })}
                      ></textarea>
                    </div>
                  </div>
                </div>
                <div className="modal-footer">
                  <button type="button" className="btn btn-light" onClick={() => setShowModal(false)}>Cancel</button>
                  <button type="submit" className="btn btn-primary">
                    <i className="bi bi-send-fill me-1"></i> Publish Announcement
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* DELETE MODAL */}
      {deleteTarget && (
        <div className="modal show d-block" tabIndex="-1" style={{ backgroundColor: 'rgba(0,0,0,0.5)' }}>
          <div className="modal-dialog modal-dialog-centered">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title fw-bold text-danger">Delete Announcement</h5>
                <button type="button" className="btn-close" onClick={() => setDeleteTarget(null)}></button>
              </div>
              <div className="modal-body">
                <p>Are you sure you want to delete notice <strong>"{deleteTarget.title}"</strong>?</p>
              </div>
              <div className="modal-footer">
                <button type="button" className="btn btn-light" onClick={() => setDeleteTarget(null)}>Cancel</button>
                <button type="button" className="btn btn-danger" onClick={handleDelete}>Delete Notice</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
