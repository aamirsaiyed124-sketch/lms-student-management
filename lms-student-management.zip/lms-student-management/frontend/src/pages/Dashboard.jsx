import React, { useEffect, useState } from 'react';
import axiosClient from '../api/axiosClient';
import StatCard from '../components/StatCard';

export default function Dashboard({ setActiveTab, showAlert }) {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  const fetchDashboard = async () => {
    try {
      setLoading(true);
      const res = await axiosClient.get('/dashboard.php');
      if (res.success) {
        setData(res.data);
      }
    } catch (err) {
      showAlert(err.message, 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDashboard();
  }, []);

  if (loading) {
    return (
      <div className="d-flex justify-content-center align-items-center py-5">
        <div className="spinner-border text-primary" role="status">
          <span className="visually-hidden">Loading dashboard...</span>
        </div>
      </div>
    );
  }

  const stats = data?.stats || {};
  const departments = data?.departments || [];
  const recentEnrollments = data?.recent_enrollments || [];
  const announcements = data?.announcements || [];

  return (
    <div className="fade-in">
      {/* Page Header */}
      <div className="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
        <div>
          <h3 className="fw-bold mb-1">Academic Dashboard</h3>
          <p className="text-muted mb-0">Overview of student enrollment, departmental statistics, and attendance.</p>
        </div>
        <div className="d-flex gap-2">
          <button 
            className="btn btn-outline-primary d-flex align-items-center gap-2"
            onClick={fetchDashboard}
          >
            <i className="bi bi-arrow-clockwise"></i>
            <span>Refresh</span>
          </button>
          <button 
            className="btn btn-primary d-flex align-items-center gap-2"
            onClick={() => setActiveTab('students')}
          >
            <i className="bi bi-person-plus-fill"></i>
            <span>Manage Students</span>
          </button>
        </div>
      </div>

      {/* Metric Cards Row */}
      <div className="row g-3 mb-4">
        <div className="col-12 col-sm-6 col-xl-3">
          <StatCard
            title="Total Students"
            value={stats.total_students || 0}
            icon="bi-people-fill"
            color="primary"
            subtitle={`${stats.active_students || 0} active accounts`}
          />
        </div>
        <div className="col-12 col-sm-6 col-xl-3">
          <StatCard
            title="Courses Offered"
            value={stats.total_courses || 0}
            icon="bi-journal-bookmark-fill"
            color="success"
            subtitle="Accredited subjects"
          />
        </div>
        <div className="col-12 col-sm-6 col-xl-3">
          <StatCard
            title="Active Enrollments"
            value={stats.total_enrollments || 0}
            icon="bi-card-checklist"
            color="info"
            subtitle="Student registrations"
          />
        </div>
        <div className="col-12 col-sm-6 col-xl-3">
          <StatCard
            title="Today's Attendance"
            value={stats.today_attendance || 0}
            icon="bi-calendar-check-fill"
            color="warning"
            subtitle="Recorded entries"
          />
        </div>
      </div>

      <div className="row g-4 mb-4">
        {/* Department Distribution */}
        <div className="col-12 col-lg-5">
          <div className="card custom-table-card h-100 p-3">
            <div className="d-flex justify-content-between align-items-center mb-3">
              <h6 className="fw-bold mb-0 text-dark d-flex align-items-center gap-2">
                <i className="bi bi-pie-chart-fill text-primary"></i>
                <span>Department Breakdown</span>
              </h6>
              <span className="badge bg-light text-muted border">{departments.length} Departments</span>
            </div>

            <div className="d-flex flex-column gap-3 mt-2">
              {departments.length === 0 ? (
                <p className="text-muted small">No department data available.</p>
              ) : (
                departments.map((dept, idx) => {
                  const percentage = stats.total_students > 0 
                    ? Math.round((Number(dept.student_count) / stats.total_students) * 100)
                    : 0;
                  return (
                    <div key={idx}>
                      <div className="d-flex justify-content-between small fw-medium mb-1">
                        <span>{dept.department}</span>
                        <span className="text-muted">{dept.student_count} students ({percentage}%)</span>
                      </div>
                      <div className="progress" style={{ height: '8px' }}>
                        <div 
                          className={`progress-bar ${idx % 2 === 0 ? 'bg-primary' : 'bg-info'}`} 
                          role="progressbar" 
                          style={{ width: `${percentage}%` }}
                        ></div>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </div>

        {/* Urgent & Recent Announcements */}
        <div className="col-12 col-lg-7">
          <div className="card custom-table-card h-100 p-3">
            <div className="d-flex justify-content-between align-items-center mb-3">
              <h6 className="fw-bold mb-0 text-dark d-flex align-items-center gap-2">
                <i className="bi bi-megaphone-fill text-warning"></i>
                <span>Recent Notices & Circulars</span>
              </h6>
              <button 
                className="btn btn-sm btn-link text-decoration-none p-0"
                onClick={() => setActiveTab('notices')}
              >
                View All &rarr;
              </button>
            </div>

            <div className="list-group list-group-flush">
              {announcements.length === 0 ? (
                <p className="text-muted small">No announcements posted yet.</p>
              ) : (
                announcements.map((item) => (
                  <div key={item.id} className="list-group-item px-0 py-2.5 border-bottom border-light">
                    <div className="d-flex justify-content-between align-items-start gap-2">
                      <div className="fw-semibold text-dark fs-6">{item.title}</div>
                      <span className={`badge ${item.priority === 'Urgent' ? 'bg-danger' : item.priority === 'High' ? 'bg-warning text-dark' : 'bg-primary-subtle text-primary'}`}>
                        {item.priority}
                      </span>
                    </div>
                    <p className="text-muted small mb-1 mt-1">{item.content}</p>
                    <div className="d-flex align-items-center gap-3 text-muted" style={{ fontSize: '0.75rem' }}>
                      <span><i className="bi bi-person me-1"></i>{item.posted_by}</span>
                      <span><i className="bi bi-building me-1"></i>{item.target_department}</span>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Recent Enrollments Table */}
      <div className="card custom-table-card p-3">
        <div className="d-flex justify-content-between align-items-center mb-3">
          <h6 className="fw-bold mb-0 text-dark d-flex align-items-center gap-2">
            <i className="bi bi-clock-history text-success"></i>
            <span>Latest Course Enrollments</span>
          </h6>
          <button 
            className="btn btn-sm btn-link text-decoration-none p-0"
            onClick={() => setActiveTab('enrollments')}
          >
            Manage Enrollments &rarr;
          </button>
        </div>

        <div className="table-responsive">
          <table className="table table-hover align-middle mb-0">
            <thead>
              <tr>
                <th>Student</th>
                <th>Roll Code</th>
                <th>Department</th>
                <th>Course</th>
                <th>Date</th>
                <th>Status</th>
                <th>Grade</th>
              </tr>
            </thead>
            <tbody>
              {recentEnrollments.length === 0 ? (
                <tr>
                  <td colSpan="7" className="text-center py-4 text-muted">No enrollments recorded yet.</td>
                </tr>
              ) : (
                recentEnrollments.map((item) => (
                  <tr key={item.id}>
                    <td className="fw-semibold text-dark">{item.student_name}</td>
                    <td><span className="badge bg-light text-secondary border">{item.student_code}</span></td>
                    <td>{item.department}</td>
                    <td>
                      <div>
                        <span className="fw-medium">{item.course_title}</span>
                        <small className="text-muted ms-1">({item.course_code})</small>
                      </div>
                    </td>
                    <td className="text-muted small">{item.enrollment_date}</td>
                    <td>
                      <span className={`badge ${item.status === 'Completed' ? 'bg-success' : item.status === 'Dropped' ? 'bg-danger' : 'bg-primary'}`}>
                        {item.status}
                      </span>
                    </td>
                    <td>
                      <span className="badge bg-secondary-subtle text-secondary border">
                        {item.grade || 'Pending'}
                      </span>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
