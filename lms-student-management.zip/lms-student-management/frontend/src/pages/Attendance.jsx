import React, { useEffect, useState } from 'react';
import axiosClient from '../api/axiosClient';

export default function Attendance({ showAlert }) {
  const [courses, setCourses] = useState([]);
  const [selectedCourse, setSelectedCourse] = useState('');
  const [attendanceDate, setAttendanceDate] = useState(new Date().toISOString().split('T')[0]);
  const [roster, setRoster] = useState([]);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);

  // Tab view: 'sheet' (mark attendance) or 'logs' (history)
  const [viewMode, setViewMode] = useState('sheet');
  const [recentLogs, setRecentLogs] = useState([]);
  const [logsLoading, setLogsLoading] = useState(false);

  const fetchCourses = async () => {
    try {
      const res = await axiosClient.get('/courses.php');
      if (res.success && res.data.length > 0) {
        setCourses(res.data);
        setSelectedCourse(res.data[0].id);
      }
    } catch (err) {
      showAlert(err.message, 'error');
    }
  };

  const fetchAttendanceSheet = async (courseId, date) => {
    if (!courseId) return;
    try {
      setLoading(true);
      const res = await axiosClient.get(`/attendance.php?course_id=${courseId}&date=${date}`);
      if (res.success) {
        // Initialize status and remarks
        const studentsWithState = (res.data.students || []).map((s) => ({
          student_id: s.student_id,
          student_code: s.student_code,
          student_name: s.student_name,
          department: s.department,
          status: s.attendance_status || 'Present',
          remarks: s.remarks || '',
          is_marked: s.is_marked === 1
        }));
        setRoster(studentsWithState);
      }
    } catch (err) {
      showAlert(err.message, 'error');
    } finally {
      setLoading(false);
    }
  };

  const fetchRecentLogs = async () => {
    try {
      setLogsLoading(true);
      const res = await axiosClient.get('/attendance.php');
      if (res.success) {
        setRecentLogs(res.data);
      }
    } catch (err) {
      showAlert(err.message, 'error');
    } finally {
      setLogsLoading(false);
    }
  };

  useEffect(() => {
    fetchCourses();
  }, []);

  useEffect(() => {
    if (selectedCourse && attendanceDate) {
      fetchAttendanceSheet(selectedCourse, attendanceDate);
    }
  }, [selectedCourse, attendanceDate]);

  useEffect(() => {
    if (viewMode === 'logs') {
      fetchRecentLogs();
    }
  }, [viewMode]);

  const handleStatusChange = (studentId, newStatus) => {
    setRoster((prev) =>
      prev.map((s) => (s.student_id === studentId ? { ...s, status: newStatus } : s))
    );
  };

  const handleRemarksChange = (studentId, newRemarks) => {
    setRoster((prev) =>
      prev.map((s) => (s.student_id === studentId ? { ...s, remarks: newRemarks } : s))
    );
  };

  const handleMarkAll = (status) => {
    setRoster((prev) => prev.map((s) => ({ ...s, status })));
  };

  const handleSaveAttendance = async () => {
    if (roster.length === 0) {
      showAlert('No students to save attendance for', 'warning');
      return;
    }

    setSaving(true);
    try {
      const payload = {
        course_id: selectedCourse,
        attendance_date: attendanceDate,
        records: roster.map((s) => ({
          student_id: s.student_id,
          status: s.status,
          remarks: s.remarks
        }))
      };

      const res = await axiosClient.post('/attendance.php', payload);
      if (res.success) {
        showAlert(res.message || 'Attendance saved successfully', 'success');
        fetchAttendanceSheet(selectedCourse, attendanceDate);
      }
    } catch (err) {
      showAlert(err.message, 'error');
    } finally {
      setSaving(false);
    }
  };

  const currentCourseInfo = courses.find((c) => String(c.id) === String(selectedCourse));

  const presentCount = roster.filter((r) => r.status === 'Present').length;
  const lateCount = roster.filter((r) => r.status === 'Late').length;
  const absentCount = roster.filter((r) => r.status === 'Absent').length;

  return (
    <div className="fade-in">
      {/* Header */}
      <div className="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
        <div>
          <h3 className="fw-bold mb-1">Attendance Tracker</h3>
          <p className="text-muted mb-0">Record lecture attendance by subject, track absences, and view audit history.</p>
        </div>
        <div className="btn-group">
          <button
            className={`btn ${viewMode === 'sheet' ? 'btn-primary' : 'btn-outline-primary'}`}
            onClick={() => setViewMode('sheet')}
          >
            <i className="bi bi-card-checklist me-1"></i> Mark Attendance
          </button>
          <button
            className={`btn ${viewMode === 'logs' ? 'btn-primary' : 'btn-outline-primary'}`}
            onClick={() => setViewMode('logs')}
          >
            <i className="bi bi-clock-history me-1"></i> Attendance Logs
          </button>
        </div>
      </div>

      {viewMode === 'sheet' ? (
        <>
          {/* Filter Bar */}
          <div className="card custom-table-card p-3 mb-4">
            <div className="row g-3 align-items-end">
              <div className="col-12 col-md-5">
                <label className="form-label small fw-semibold">Select Course</label>
                <select
                  className="form-select"
                  value={selectedCourse}
                  onChange={(e) => setSelectedCourse(e.target.value)}
                >
                  {courses.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.course_code} - {c.title} ({c.instructor_name})
                    </option>
                  ))}
                </select>
              </div>

              <div className="col-12 col-sm-6 col-md-3">
                <label className="form-label small fw-semibold">Session Date</label>
                <input
                  type="date"
                  className="form-control"
                  value={attendanceDate}
                  onChange={(e) => setAttendanceDate(e.target.value)}
                />
              </div>

              <div className="col-12 col-sm-6 col-md-4">
                <div className="d-flex gap-2">
                  <button
                    type="button"
                    className="btn btn-outline-success btn-sm flex-fill"
                    onClick={() => handleMarkAll('Present')}
                    disabled={roster.length === 0}
                  >
                    All Present
                  </button>
                  <button
                    type="button"
                    className="btn btn-outline-danger btn-sm flex-fill"
                    onClick={() => handleMarkAll('Absent')}
                    disabled={roster.length === 0}
                  >
                    All Absent
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Quick Summary Pill Bar */}
          {roster.length > 0 && (
            <div className="alert alert-light border d-flex flex-wrap justify-content-between align-items-center mb-4 py-2 px-3">
              <div className="small text-muted">
                Course: <strong>{currentCourseInfo?.title}</strong> ({currentCourseInfo?.course_code}) &bull; Date: <strong>{attendanceDate}</strong>
              </div>
              <div className="d-flex gap-2">
                <span className="badge bg-success-subtle text-success border border-success-subtle">
                  {presentCount} Present
                </span>
                <span className="badge bg-warning-subtle text-warning border border-warning-subtle">
                  {lateCount} Late
                </span>
                <span className="badge bg-danger-subtle text-danger border border-danger-subtle">
                  {absentCount} Absent
                </span>
              </div>
            </div>
          )}

          {/* Attendance Table */}
          <div className="card custom-table-card mb-4">
            <div className="table-responsive">
              <table className="table table-hover align-middle mb-0">
                <thead>
                  <tr>
                    <th>Student</th>
                    <th>Roll Code</th>
                    <th>Department</th>
                    <th>Status</th>
                    <th>Remarks / Notes</th>
                  </tr>
                </thead>
                <tbody>
                  {loading ? (
                    <tr>
                      <td colSpan="5" className="text-center py-5">
                        <div className="spinner-border spinner-border-sm text-primary me-2"></div>
                        <span className="text-muted">Loading enrolled students...</span>
                      </td>
                    </tr>
                  ) : roster.length === 0 ? (
                    <tr>
                      <td colSpan="5" className="text-center py-5 text-muted">
                        <i className="bi bi-people fs-1 d-block mb-2 text-secondary"></i>
                        No students are enrolled in this course yet.
                      </td>
                    </tr>
                  ) : (
                    roster.map((stu) => (
                      <tr key={stu.student_id}>
                        <td>
                          <div className="fw-semibold text-dark">{stu.student_name}</div>
                        </td>
                        <td>
                          <span className="badge bg-light text-secondary border font-monospace">
                            {stu.student_code}
                          </span>
                        </td>
                        <td>{stu.department}</td>
                        <td>
                          <div className="btn-group btn-group-sm btn-attendance-group" role="group">
                            <button
                              type="button"
                              className={`btn ${stu.status === 'Present' ? 'btn-success' : 'btn-outline-secondary'}`}
                              onClick={() => handleStatusChange(stu.student_id, 'Present')}
                            >
                              Present
                            </button>
                            <button
                              type="button"
                              className={`btn ${stu.status === 'Late' ? 'btn-warning' : 'btn-outline-secondary'}`}
                              onClick={() => handleStatusChange(stu.student_id, 'Late')}
                            >
                              Late
                            </button>
                            <button
                              type="button"
                              className={`btn ${stu.status === 'Absent' ? 'btn-danger' : 'btn-outline-secondary'}`}
                              onClick={() => handleStatusChange(stu.student_id, 'Absent')}
                            >
                              Absent
                            </button>
                            <button
                              type="button"
                              className={`btn ${stu.status === 'Excused' ? 'btn-info' : 'btn-outline-secondary'}`}
                              onClick={() => handleStatusChange(stu.student_id, 'Excused')}
                            >
                              Excused
                            </button>
                          </div>
                        </td>
                        <td>
                          <input
                            type="text"
                            className="form-control form-control-sm"
                            placeholder="Optional remark..."
                            value={stu.remarks}
                            onChange={(e) => handleRemarksChange(stu.student_id, e.target.value)}
                          />
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>

            {roster.length > 0 && (
              <div className="card-footer bg-white border-top p-3 d-flex justify-content-end">
                <button
                  type="button"
                  className="btn btn-primary d-flex align-items-center gap-2"
                  onClick={handleSaveAttendance}
                  disabled={saving}
                >
                  {saving ? (
                    <>
                      <span className="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                      <span>Saving Records...</span>
                    </>
                  ) : (
                    <>
                      <i className="bi bi-save2-fill"></i>
                      <span>Save Attendance Sheet</span>
                    </>
                  )}
                </button>
              </div>
            )}
          </div>
        </>
      ) : (
        /* Logs view */
        <div className="card custom-table-card">
          <div className="p-3 border-bottom d-flex justify-content-between align-items-center">
            <h6 className="fw-bold mb-0 text-dark">Recent Attendance Activity Logs</h6>
            <button className="btn btn-sm btn-outline-primary" onClick={fetchRecentLogs}>
              <i className="bi bi-arrow-clockwise me-1"></i> Refresh Logs
            </button>
          </div>
          <div className="table-responsive">
            <table className="table table-hover align-middle mb-0">
              <thead>
                <tr>
                  <th>Date</th>
                  <th>Student</th>
                  <th>Roll Code</th>
                  <th>Course</th>
                  <th>Status</th>
                  <th>Remarks</th>
                </tr>
              </thead>
              <tbody>
                {logsLoading ? (
                  <tr>
                    <td colSpan="6" className="text-center py-5">
                      <div className="spinner-border spinner-border-sm text-primary me-2"></div>
                      <span className="text-muted">Loading logs...</span>
                    </td>
                  </tr>
                ) : recentLogs.length === 0 ? (
                  <tr>
                    <td colSpan="6" className="text-center py-5 text-muted">No attendance activity recorded yet.</td>
                  </tr>
                ) : (
                  recentLogs.map((log) => (
                    <tr key={log.id}>
                      <td className="text-muted small">{log.attendance_date}</td>
                      <td className="fw-semibold text-dark">{log.student_name}</td>
                      <td><span className="badge bg-light text-secondary border font-monospace">{log.student_code}</span></td>
                      <td>
                        <div>
                          <span className="fw-medium">{log.course_title}</span>
                          <small className="text-muted ms-1">({log.course_code})</small>
                        </div>
                      </td>
                      <td>
                        <span className={`badge ${log.status === 'Present' ? 'bg-success-subtle text-success' : log.status === 'Late' ? 'bg-warning-subtle text-warning' : log.status === 'Absent' ? 'bg-danger-subtle text-danger' : 'bg-info-subtle text-info'}`}>
                          {log.status}
                        </span>
                      </td>
                      <td className="text-muted small">{log.remarks || '-'}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
