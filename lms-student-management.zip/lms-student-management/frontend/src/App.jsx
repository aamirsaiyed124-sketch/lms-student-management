import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import Sidebar from './components/Sidebar';
import ToastAlert from './components/ToastAlert';
import Dashboard from './pages/Dashboard';
import Students from './pages/Students';
import Courses from './pages/Courses';
import Enrollments from './pages/Enrollments';
import Attendance from './pages/Attendance';
import Notices from './pages/Notices';
import LoginChoice from './pages/LoginChoice';
import AdminLogin from './pages/AdminLogin';
import UserLogin from './pages/UserLogin';
import axiosClient from './api/axiosClient';

export default function App() {
  const [user, setUser] = useState(null);
  const [loginScreen, setLoginScreen] = useState('choice');
  const [checkingSession, setCheckingSession] = useState(true);
  const [activeTab, setActiveTab] = useState('dashboard');
  const [serverOnline, setServerOnline] = useState(false);
  const [alert, setAlert] = useState(null);

  const showAlert = (message, type = 'success') => setAlert({ message, type });

  useEffect(() => {
    if (alert) {
      const timer = setTimeout(() => setAlert(null), 4000);
      return () => clearTimeout(timer);
    }
  }, [alert]);

  useEffect(() => {
    axiosClient.get('/auth.php?action=me')
      .then((res) => {
        if (res?.success && res.data) setUser(res.data);
      })
      .catch(() => {})
      .finally(() => setCheckingSession(false));
  }, []);

  const checkServerStatus = async () => {
    try {
      const res = await axiosClient.get('/dashboard.php');
      setServerOnline(Boolean(res?.success));
    } catch {
      setServerOnline(false);
    }
  };

  useEffect(() => {
    if (!user) return;
    checkServerStatus();
    const interval = setInterval(checkServerStatus, 20000);
    return () => clearInterval(interval);
  }, [user]);

  const handleLogout = async () => {
    try { await axiosClient.post('/auth.php?action=logout'); } catch {}
    setUser(null);
    setActiveTab('dashboard');
    setLoginScreen('choice');
  };

  if (checkingSession) {
    return <div className="min-vh-100 d-flex align-items-center justify-content-center bg-light"><div className="text-center"><div className="spinner-border text-primary mb-3"></div><div className="text-muted">Checking login session...</div></div></div>;
  }

  if (!user) {
    if (loginScreen === 'admin') return <AdminLogin onLogin={setUser} onBack={() => setLoginScreen('choice')} />;
    if (loginScreen === 'user') return <UserLogin onLogin={setUser} onBack={() => setLoginScreen('choice')} />;
    return <LoginChoice onSelect={setLoginScreen} />;
  }

  const isAdmin = user.role === 'admin';

  return (
    <div className="d-flex min-vh-100 bg-light">
      <ToastAlert alert={alert} onClose={() => setAlert(null)} />
      <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} role={user.role} />
      <div className="d-flex flex-column flex-grow-1" style={{ minWidth: 0 }}>
        <Navbar serverStatus={serverOnline} user={user} onLogout={handleLogout} />
        <main className="flex-grow-1 p-3 p-md-4 p-xl-5">
          {activeTab === 'dashboard' && <Dashboard setActiveTab={setActiveTab} showAlert={showAlert} />}
          {activeTab === 'students' && isAdmin && <Students showAlert={showAlert} />}
          {activeTab === 'courses' && <Courses showAlert={showAlert} role={user.role} />}
          {activeTab === 'enrollments' && isAdmin && <Enrollments showAlert={showAlert} />}
          {activeTab === 'attendance' && isAdmin && <Attendance showAlert={showAlert} />}
          {activeTab === 'notices' && <Notices showAlert={showAlert} role={user.role} />}
        </main>
      </div>
    </div>
  );
}
